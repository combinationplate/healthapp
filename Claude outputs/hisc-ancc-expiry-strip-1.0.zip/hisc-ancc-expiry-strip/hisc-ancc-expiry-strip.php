<?php
/**
 * Plugin Name: HISC ANCC Expiry Strip (one-time)
 * Description: Removes the "(Expires MM/DD/YYYY)" parenthetical that follows the ANCC / Nurses accreditation statement in WooCommerce product descriptions. Preview first, then Apply. Deactivate and delete when done.
 * Version: 1.0
 * Author: H.I.S. Cornerstone
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* Only the parenthetical that directly follows the ANCC statement is touched.
   PT / OT / SLP "(Expires ...)" notes are left alone and are reported so you
   can see them. Whitespace, &nbsp; and a stray period are tolerated. */
function hisc_aes_pattern() {
    return '/(Commission\s+on\s+Accreditation\.?)((?:\s|&nbsp;|\x{00A0})*)\(\s*Expires\s+\d{1,2}\/\d{1,2}\/\d{2,4}\s*\)/iu';
}

/** Returns array( new_text, n_replaced ). */
function hisc_aes_strip( $text ) {
    $n = 0;
    $new = preg_replace_callback( hisc_aes_pattern(), function ( $m ) use ( &$n ) {
        $n++;
        return $m[1];
    }, (string) $text );
    if ( $new === null ) return array( (string) $text, 0 ); // regex error: leave untouched
    return array( $new, $n );
}

/** Count "(Expires ...)" notes that remain after stripping (non-ANCC ones). */
function hisc_aes_other_expires( $text ) {
    return preg_match_all( '/\(\s*Expires\s+\d{1,2}\/\d{1,2}\/\d{2,4}\s*\)/i', (string) $text );
}

/** Recursively strip inside a decoded Elementor data tree. Returns count. */
function hisc_aes_walk( &$node ) {
    $n = 0;
    if ( is_array( $node ) ) {
        foreach ( $node as $k => &$v ) $n += hisc_aes_walk( $v );
        unset( $v );
    } elseif ( is_string( $node ) && stripos( $node, 'Expires' ) !== false ) {
        list( $node, $c ) = hisc_aes_strip( $node );
        $n += $c;
    }
    return $n;
}

/** Short before/after context around the first match, for the preview table. */
function hisc_aes_snippet( $text ) {
    if ( ! preg_match( hisc_aes_pattern(), (string) $text, $m, PREG_OFFSET_CAPTURE ) ) return '';
    $start = max( 0, $m[0][1] - 40 );
    $len   = strlen( $m[0][0] ) + 80;
    return '…' . wp_strip_all_tags( substr( (string) $text, $start, $len ) ) . '…';
}

add_action( 'admin_menu', function () {
    add_management_page( 'HISC ANCC Expiry Strip', 'HISC ANCC Expiry Strip', 'manage_options', 'hisc-ancc-expiry-strip', 'hisc_aes_page' );
} );

function hisc_aes_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $apply = isset( $_POST['hisc_aes_apply'] ) && check_admin_referer( 'hisc_aes' );

    echo '<div class="wrap"><h1>HISC ANCC Expiry Strip ' . ( $apply ? '&mdash; APPLIED' : '&mdash; PREVIEW' ) . '</h1>';
    echo '<p>Finds every product whose description, short description, or Elementor content contains the ANCC statement followed by <code>(Expires MM/DD/YYYY)</code> and removes just that parenthetical. Nothing else in the text is changed. Safe to run more than once.</p>';

    $products = get_posts( array( 'post_type' => 'product', 'numberposts' => -1, 'post_status' => array( 'publish', 'draft', 'private', 'pending' ) ) );
    $rows = array(); $n_products = 0; $n_total = 0; $n_other = 0;

    foreach ( $products as $p ) {
        $hit = false; $detail = array();

        // post_content + post_excerpt
        $upd = array();
        foreach ( array( 'post_content' => 'Description', 'post_excerpt' => 'Short description' ) as $col => $label ) {
            list( $new, $c ) = hisc_aes_strip( $p->$col );
            $n_other += hisc_aes_other_expires( $new );
            if ( $c > 0 ) {
                $hit = true; $n_total += $c;
                $detail[] = "$label: $c removed &mdash; <em>" . esc_html( hisc_aes_snippet( $p->$col ) ) . '</em>';
                $upd[ $col ] = $new;
            }
        }
        if ( $apply && $upd ) {
            $upd['ID'] = $p->ID;
            remove_all_actions( 'save_post' ); // keep it a plain text edit: no other plugins re-processing
            wp_update_post( wp_slash( $upd ) );
        }

        // Elementor JSON (if the product was built with Elementor)
        $el = get_post_meta( $p->ID, '_elementor_data', true );
        if ( is_string( $el ) && $el !== '' && stripos( $el, 'Expires' ) !== false ) {
            $tree = json_decode( $el, true );
            if ( is_array( $tree ) ) {
                $c = hisc_aes_walk( $tree );
                if ( $c > 0 ) {
                    $hit = true; $n_total += $c;
                    $detail[] = "Elementor content: $c removed";
                    if ( $apply ) {
                        update_post_meta( $p->ID, '_elementor_data', wp_slash( wp_json_encode( $tree ) ) );
                        if ( class_exists( '\Elementor\Plugin' ) ) \Elementor\Plugin::$instance->files_manager->clear_cache();
                    }
                }
            }
        }

        if ( $hit ) {
            $n_products++;
            $rows[] = '<tr><td><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></td><td style="font-size:12px">' . implode( '<br>', $detail ) . '</td></tr>';
        }
    }

    if ( $rows ) {
        echo '<table class="widefat striped"><thead><tr><th style="width:35%">Product</th><th>What ' . ( $apply ? 'changed' : 'will change' ) . '</th></tr></thead><tbody>' . implode( '', $rows ) . '</tbody></table>';
    }
    printf( '<p><strong>%d product(s), %d parenthetical(s) %s.</strong></p>', $n_products, $n_total, $apply ? 'removed' : 'to remove' );
    if ( $n_other ) printf( '<p>Note: %d other "(Expires …)" note(s) (PT/OT/SLP board approvals) were found and deliberately left in place.</p>', $n_other );

    if ( ! $apply && $n_products ) {
        echo '<form method="post">'; wp_nonce_field( 'hisc_aes' );
        echo '<p><button class="button button-primary" name="hisc_aes_apply" value="1">Apply &mdash; remove from all listed products</button></p></form>';
    } elseif ( $apply ) {
        echo '<p>Done. Hard-refresh a product page to confirm, then deactivate and delete this plugin.</p>';
    } elseif ( ! $n_products ) {
        echo '<p>Nothing to do &mdash; no product text contains the ANCC statement followed by an expiration. If the product page still shows one, the text lives in a theme template or a shortcode rather than the product description.</p>';
    }
    echo '</div>';
}
