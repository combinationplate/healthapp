<?php
/**
 * Plugin Name: HIS Cornerstone CE Toolkit
 * Description: CE Provider Settings page + master-certificate shortcodes ([hisc_hours], [hisc_license], [hisc_statements]) + Group QuickJoin QR enrollment. Requires ACF Pro with the HISC field groups imported.
 * Version: 2.4.0
 * Author: H.I.S. Cornerstone
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* Group QuickJoin module (v2.3): QR flyer -> direct enrollment into LearnDash groups */
require_once plugin_dir_path( __FILE__ ) . 'hisc-quickjoin.php';

/* Auto-load the group-order filter script on the front end, versioned by file
   modification time so cache-busting is automatic (no manual ?v= bumping).
   The script no-ops on any page that doesn't define window.HISC_FILTER. */
add_action( 'wp_enqueue_scripts', function () {
    $path = plugin_dir_path( __FILE__ ) . 'hisc-course-filter.js';
    $url  = plugin_dir_url( __FILE__ ) . 'hisc-course-filter.js';
    if ( file_exists( $path ) ) {
        wp_enqueue_script( 'hisc-course-filter', $url, array(), filemtime( $path ), true );
    }
} );


/* CE Provider Settings page (appears in the left admin menu) */
add_action( 'acf/init', function () {
    if ( function_exists( 'acf_add_options_page' ) ) {
        acf_add_options_page( array(
            'page_title' => 'CE Provider Settings',
            'menu_title' => 'CE Settings',
            'menu_slug'  => 'hisc-ce-settings',
            'capability' => 'manage_options',
            'redirect'   => false,
            'icon_url'   => 'dashicons-awards',
        ) );
    }
} );

function hisc_cert_course_id() {
    if ( ! empty( $_GET['course_id'] ) ) return absint( $_GET['course_id'] );
    if ( function_exists( 'learndash_get_course_id' ) ) { $id = learndash_get_course_id(); if ( $id ) return $id; }
    return get_the_ID();
}

add_shortcode( 'hisc_hours', function () {
    $h = get_field( 'credit_hours', hisc_cert_course_id() );
    return $h !== null && $h !== '' ? esc_html( number_format( (float) $h, 1 ) ) : '';
} );

add_shortcode( 'hisc_license', function () {
    $user_id = ! empty( $_GET['user_id'] ) ? absint( $_GET['user_id'] ) : get_current_user_id();
    $lic = '';
    if ( $user_id ) {
        $lic = function_exists( 'get_field' ) ? get_field( 'license_number', 'user_' . $user_id ) : '';
        if ( ! $lic ) $lic = get_user_meta( $user_id, 'license_number', true );
    }
    return $lic ? esc_html( $lic ) : '_______________';
} );

add_shortcode( 'hisc_statements', function ( $atts = array() ) {
    $a = shortcode_atts( array( 'size' => '9', 'show_expirations' => 'no', 'spacing' => 'single' ), $atts );
    $show_exp = ( 'yes' === strtolower( $a['show_expirations'] ) );
    $exp = function ( $field, $cid ) use ( $show_exp ) {
        if ( ! $show_exp ) return '';
        $d = get_field( $field, 'option' === $cid ? 'option' : $cid );
        return $d ? ' (Expires ' . esc_html( $d ) . ')' : '';
    };
    $cid   = hisc_cert_course_id();
    $d     = (array) get_field( 'disciplines', $cid );
    $hours = get_field( 'credit_hours', $cid );
    $out   = array();

    if ( in_array( 'rn', $d, true ) ) {
        /* v2.4: the ANCC provider statement never carries an expiration date
           (ANCC accreditation is provider-level; the date confused learners). */
        $out[] = '<strong>Nurses:</strong> ' . esc_html( get_field( 'ancc_statement', 'option' ) );
    }
    if ( in_array( 'sw_lpc', $d, true ) ) {
        $out[] = sprintf(
            '<strong>Social Workers &amp; Licensed Professional Counselors:</strong> HIS Cornerstone, provider #%s, is approved as an ACE provider to offer social work continuing education by the Association of Social Work Boards (ASWB) Approved Continuing Education (ACE) program. Regulatory boards are the final authority on courses accepted for continuing education credit. ACE provider approval period: %s&ndash;%s. Social workers completing this course receive %s general continuing education credits.',
            esc_html( get_field( 'ace_provider_number', 'option' ) ),
            esc_html( get_field( 'ace_period_start', 'option' ) ),
            esc_html( get_field( 'ace_period_end', 'option' ) ),
            esc_html( $hours )
        );
    }
    $pt = get_field( 'pt_approval_number', $cid );
    if ( in_array( 'pt', $d, true ) && $pt ) {
        $out[] = sprintf(
            '<strong>Physical Therapists/PTAs:</strong> This activity has been approved by the Texas Board of Physical Therapy Examiners for %s CCUs for PTs and PTAs. TX Approval Number: %s.',
            esc_html( number_format( (float) get_field( 'pt_ccus', $cid ), 2 ) ), esc_html( $pt )
        ) . $exp( 'pt_expiration', $cid );
    }
    $ot = get_field( 'ot_approval_number', $cid );
    if ( in_array( 'ot', $d, true ) && $ot ) {
        $out[] = sprintf(
            '<strong>Occupational Therapists/OTAs:</strong> The TOTA Continuing Education Review Committee has approved this course for: %s contact hour / %s CEUs of OT Education. TOTA approval #%s.',
            esc_html( $hours ), esc_html( number_format( (float) get_field( 'ot_ceus', $cid ), 1 ) ), esc_html( $ot )
        ) . $exp( 'ot_expiration', $cid );
    }
    $tsha = get_field( 'tsha_id', $cid );
    if ( in_array( 'slp', $d, true ) && $tsha ) {
        $out[] = sprintf(
            '<strong>Speech-Language Pathologists/Audiologists:</strong> This program has been approved for %s clock hours of continuing education credit by the Texas Speech-Language-Hearing Association (TSHA). TSHA continuing education hours can be used toward renewal of your Texas license and as professional development activities for the maintenance of your ASHA Certificate of Clinical Competence (CCC). (ID: %s)',
            esc_html( get_field( 'slp_clock_hours', $cid ) ), esc_html( $tsha )
        ) . $exp( 'slp_expiration', $cid );
    }
    if ( in_array( 'cm', $d, true ) ) {
        $out[] = esc_html( get_field( 'acma_ccmc_statement', 'option' ) );
    }
    $sep = ( 'double' === strtolower( $a['spacing'] ) ) ? '<br/><br/>' : '<br/>';
    return '<span style="font-size:' . absint( $a['size'] ) . 'px; line-height:1.5;">' . implode( $sep, $out ) . '</span>';
} );

/* [hisc_title size="22"] — course title in an mPDF-safe table so it wraps at whole words */
add_shortcode( 'hisc_title', function ( $atts ) {
    $a = shortcode_atts( array( 'size' => '22' ), $atts );
    $title = get_the_title( hisc_cert_course_id() );
    // normalize non-breaking spaces and doubled spaces that break PDF word-wrapping
    $title = str_replace( array( "\xC2\xA0", '&nbsp;' ), ' ', $title );
    $title = preg_replace( '/\s+/u', ' ', $title );
    return '<table style="width:100%; border-collapse:collapse;"><tr><td style="text-align:center; font-size:' .
        absint( $a['size'] ) . 'px; font-style:italic; padding:0 40px;">' . esc_html( trim( $title ) ) . '</td></tr></table>';
} );

/* [hisc_format_line] — "Program Format: ..." from the course's CE Delivery field */
add_shortcode( 'hisc_format_line', function () {
    $labels = array(
        'self_paced'   => 'Recorded Asynchronous Distance Learning',
        'live_webinar' => 'Live Webinar',
        'in_person'    => 'Live In Person',
    );
    $d = (string) get_field( 'ce_delivery', hisc_cert_course_id() );
    if ( ! isset( $labels[ $d ] ) ) $d = 'self_paced';
    return 'Program Format:<br/>' . esc_html( $labels[ $d ] );
} );

/* ===================== Master Evaluation Form ===================== */

/** Context for the master eval: which course and which format. */
function hisc_eval_ctx( $field_values = array() ) {
    $format = 'self_paced';
    foreach ( array( 'hisc_format' ) as $k ) {
        if ( ! empty( $field_values[ $k ] ) )      $format = sanitize_key( $field_values[ $k ] );
        elseif ( ! empty( $_REQUEST[ $k ] ) )      $format = sanitize_key( $_REQUEST[ $k ] );
        elseif ( ! empty( $_POST['input_62'] ) )   $format = sanitize_key( $_POST['input_62'] );
    }
    $explicit = ( $format !== 'self_paced' ) || ! empty( $field_values['hisc_format'] ) || ! empty( $_REQUEST['hisc_format'] ) || ! empty( $_POST['input_62'] );
    if ( ! in_array( $format, array( 'self_paced', 'live_webinar', 'in_person' ), true ) ) $format = 'self_paced';

    $course_id = 0;
    if ( ! empty( $field_values['hisc_course_id'] ) )   $course_id = absint( $field_values['hisc_course_id'] );
    elseif ( ! empty( $_REQUEST['hisc_course_id'] ) )   $course_id = absint( $_REQUEST['hisc_course_id'] );
    elseif ( ! empty( $_POST['input_60'] ) )            $course_id = absint( $_POST['input_60'] );
    elseif ( function_exists( 'learndash_get_course_id' ) ) {
        $course_id = (int) learndash_get_course_id( get_the_ID() );
        if ( ! $course_id ) { global $post; if ( $post instanceof WP_Post ) $course_id = (int) learndash_get_course_id( $post->ID ); }
        if ( ! $course_id ) $course_id = (int) learndash_get_course_id();
    }

    if ( ! $explicit && $course_id && function_exists( 'get_field' ) ) {
        $delivery = (string) get_field( 'ce_delivery', $course_id );
        if ( in_array( $delivery, array( 'self_paced', 'live_webinar', 'in_person' ), true ) ) $format = $delivery;
    }
    return array( 'format' => $format, 'course_id' => $course_id );
}

/** Adapt the master eval to the current course + format. */
function hisc_eval_prepare( $form, $ajax = false, $field_values = array() ) {
    if ( empty( $form['cssClass'] ) || strpos( $form['cssClass'], 'hisc-master-eval' ) === false ) return $form;
    $ctx = hisc_eval_ctx( is_array( $field_values ) ? $field_values : array() );

    $remove = array();
    // license (46) stays on ALL formats — it is the universal, optional capture point
    if ( 'self_paced' === $ctx['format'] )   $remove = array( 44, 45, 43, 50, 51 ); // name, email, event date, arrival, departure
    if ( 'live_webinar' === $ctx['format'] ) $remove = array( 50, 51 );             // arrival, departure
    if ( 'in_person' === $ctx['format'] )    $remove = array( 45, 40 );             // email, total time

    // course objectives -> likert rows on field 36
    $objectives = array();
    if ( $ctx['course_id'] && function_exists( 'get_field' ) ) {
        $rows = get_field( 'objectives', $ctx['course_id'] );
        if ( is_array( $rows ) ) {
            foreach ( $rows as $r ) {
                $t = isset( $r['objective_text'] ) ? trim( $r['objective_text'] ) : '';
                if ( $t !== '' ) $objectives[] = $t;
            }
        }
    }

    foreach ( $form['fields'] as $key => $field ) {
        $fid = (int) $field->id;
        if ( 36 === $fid ) {
            if ( empty( $objectives ) ) {
                if ( isset( $_GET['hisc_debug'] ) && current_user_can( 'manage_options' ) ) {
                    $row = $field->gsurveyLikertRows[0];
                    $row['text'] = 'DEBUG (admins only): resolved course_id=' . $ctx['course_id'] .
                        ( $ctx['course_id'] ? ' ("' . get_the_title( $ctx['course_id'] ) . '") but its Course Objectives field is empty' : ' — could not resolve the course' );
                    $field->gsurveyLikertRows = array( $row );
                    $input = $field->inputs[0]; $input['label'] = $row['text'];
                    $field->inputs = array( $input );
                    continue;
                }
                $remove[] = 36; continue;
            }
            $objectives = array_slice( $objectives, 0, count( $field->gsurveyLikertRows ) );
            $new_rows = array(); $new_inputs = array();
            foreach ( $objectives as $i => $text ) {
                $row = $field->gsurveyLikertRows[ $i ]; $row['text'] = $text;
                $new_rows[] = $row;
                $input = $field->inputs[ $i ]; $input['label'] = $text;
                $new_inputs[] = $input;
            }
            $field->gsurveyLikertRows = $new_rows;
            $field->inputs = $new_inputs;
        }
        if ( 3 === $fid ) {
            $legend = '1 = Poor, 2 = Fair, 3 = Good, 4 = Excellent';
            $lo = ( $ctx['course_id'] && function_exists( 'get_field' ) ) ? trim( (string) get_field( 'learning_outcome', $ctx['course_id'] ) ) : '';
            $field->description = $lo !== ''
                ? '<em>Learning Outcome:</em> ' . esc_html( $lo ) . ' ' . $legend
                : $legend;
        }
        if ( 38 === $fid ) {
            $field->label = ( 'self_paced' === $ctx['format'] ) ? '• Author' : '• Instructor';
        }
    }
    $form['fields'] = array_values( array_filter( $form['fields'], function ( $f ) use ( $remove ) {
        return ! in_array( (int) $f->id, $remove, true );
    } ) );
    return $form;
}
add_filter( 'gform_pre_render', 'hisc_eval_prepare', 10, 3 );
add_filter( 'gform_pre_validation', 'hisc_eval_prepare' );
add_filter( 'gform_pre_submission_filter', 'hisc_eval_prepare' );

/* Dynamic population of the hidden context fields */
add_filter( 'gform_field_value_hisc_course_id', function () {
    $c = hisc_eval_ctx(); return $c['course_id'];
} );
add_filter( 'gform_field_value_hisc_course_title', function () {
    $c = hisc_eval_ctx(); return $c['course_id'] ? get_the_title( $c['course_id'] ) : '';
} );
add_filter( 'gform_field_value_hisc_format', function () {
    $c = hisc_eval_ctx(); return $c['format'];
} );
add_filter( 'gform_field_value_hisc_group', function () {
    if ( ! function_exists( 'learndash_get_users_group_ids' ) || ! is_user_logged_in() ) return '';
    $gids = learndash_get_users_group_ids( get_current_user_id() );
    return ! empty( $gids ) ? get_the_title( $gids[0] ) : '';
} );


/* License number glue: the live eval's License field (id 46) pre-fills from the
   logged-in user's profile, and a typed value is saved back to the profile. */
add_filter( 'gform_pre_render', function ( $form ) {
    if ( empty( $form['cssClass'] ) || strpos( $form['cssClass'], 'hisc-master-eval' ) === false ) return $form;
    if ( ! is_user_logged_in() ) return $form;
    $lic = get_user_meta( get_current_user_id(), 'license_number', true );
    if ( ! $lic ) return $form;
    foreach ( $form['fields'] as $field ) {
        if ( 46 === (int) $field->id && empty( $field->defaultValue ) ) $field->defaultValue = $lic;
    }
    return $form;
}, 20 );

add_action( 'gform_after_submission', function ( $entry, $form ) {
    if ( empty( $form['cssClass'] ) || strpos( $form['cssClass'], 'hisc-master-eval' ) === false ) return;
    if ( ! is_user_logged_in() ) return;
    $lic = isset( $entry['46'] ) ? sanitize_text_field( $entry['46'] ) : '';
    if ( $lic !== '' ) update_user_meta( get_current_user_id(), 'license_number', $lic );
}, 10, 2 );

/* ===================== Product Attribute Sync ===================== */
/* Course fields are the source of truth; product attributes (which the shop
   filter and the product page's "Additional information" tab read) are kept
   in sync. Runs automatically when a course is saved, plus a full-catalog
   preview/sync page under Tools -> HISC Product Sync.
   v2.4: Revision Date is now synced too (it was previously left alone, which
   is why editing the course's Revision Date never reached the product page).
   Works whether the attribute is a global (taxonomy) attribute or a custom
   per-product one. CE Format is still deliberately NOT touched. */

function hisc_sync_map() {
    return array(
        'Contact Hours'         => 'credit_hours',
        'Revision Date'         => 'revision_date',
        'RN Approved'           => 'rn_states',
        'SW-LCSW-LMSW Approved' => 'sw_states',
        'CCM-ACM Approved'      => 'ccm_states',
        'PT Approved'           => 'pt_states',
        'OT Approved'           => 'ot_states',
        'SLP Approved'          => 'slp_states',
        'RD Approved'           => 'rd_states',
    );
}

/** Attributes whose value is ONE string (never split on commas). */
function hisc_sync_single_value_fields() {
    return array( 'credit_hours', 'revision_date' );
}

function hisc_sync_tax_by_label() {
    static $m = null;
    if ( $m === null ) {
        $m = array();
        if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
            foreach ( wc_get_attribute_taxonomies() as $t ) {
                $m[ trim( $t->attribute_label ) ] = 'pa_' . $t->attribute_name;
            }
        }
    }
    return $m;
}

/** Map course_id => array of product posts (single-course products only). */
function hisc_sync_course_products() {
    $map = array();
    foreach ( get_posts( array( 'post_type' => 'product', 'numberposts' => -1, 'post_status' => 'publish' ) ) as $p ) {
        $rel = get_post_meta( $p->ID, '_related_course', true );
        $courses = is_array( $rel ) ? array_values( array_filter( array_map( 'intval', $rel ) ) ) : ( is_numeric( $rel ) ? array( (int) $rel ) : array() );
        if ( count( $courses ) === 1 ) $map[ $courses[0] ][] = $p;
    }
    return $map;
}

/** Desired term names for one attribute from the course field value. */
function hisc_sync_desired( $field, $course_id ) {
    $v = get_field( $field, $course_id );
    if ( $v === null || $v === '' || $v === false ) return array();
    if ( 'credit_hours' === $field ) return array( number_format( (float) $v, 1 ) );
    if ( in_array( $field, hisc_sync_single_value_fields(), true ) ) return array( trim( (string) $v ) );
    $parts = array_filter( array_map( 'trim', explode( ',', (string) $v ) ) );
    return array_values( array_unique( $parts ) );
}

/**
 * Find the key of a CUSTOM (non-taxonomy) attribute in _product_attributes by
 * its label, tolerating the slug WooCommerce may have stored it under.
 */
function hisc_sync_custom_attr_key( $meta, $label ) {
    $want = sanitize_title( $label );
    foreach ( $meta as $key => $attr ) {
        if ( ! empty( $attr['is_taxonomy'] ) ) continue;
        $name = isset( $attr['name'] ) ? (string) $attr['name'] : '';
        if ( $key === $want || sanitize_title( $name ) === $want || strcasecmp( trim( $name ), $label ) === 0 ) return $key;
    }
    return $want;
}

/**
 * Sync one product from its course. $dry = collect changes without writing.
 * Returns array of human-readable change strings (empty = already in sync).
 */
function hisc_sync_product( $product_id, $course_id, $dry = false ) {
    $changes = array();
    $taxes = hisc_sync_tax_by_label();
    $meta  = get_post_meta( $product_id, '_product_attributes', true );
    if ( ! is_array( $meta ) ) $meta = array();
    $meta_changed = false;

    foreach ( hisc_sync_map() as $label => $field ) {
        $desired = hisc_sync_desired( $field, $course_id );

        /* ---- custom (per-product) attribute: value lives in _product_attributes ---- */
        if ( empty( $taxes[ $label ] ) || ! taxonomy_exists( $taxes[ $label ] ) ) {
            if ( ! in_array( $field, hisc_sync_single_value_fields(), true ) ) continue; // state lists are taxonomy-only
            $key     = hisc_sync_custom_attr_key( $meta, $label );
            $current = isset( $meta[ $key ]['value'] ) ? trim( (string) $meta[ $key ]['value'] ) : '';
            $want    = $desired ? $desired[0] : '';
            if ( '' === $want ) continue;            // never blank a product's value from an empty course field
            if ( $current === $want ) continue;
            $changes[] = "$label: " . ( $current === '' ? 'set' : "\"$current\" ->" ) . " \"$want\"";
            if ( ! $dry ) {
                if ( ! isset( $meta[ $key ] ) ) {
                    $meta[ $key ] = array( 'name' => $label, 'value' => '', 'position' => count( $meta ),
                        'is_visible' => 1, 'is_variation' => 0, 'is_taxonomy' => 0 );
                }
                $meta[ $key ]['value'] = $want;
                $meta_changed = true;
            }
            continue;
        }

        /* ---- global (taxonomy) attribute ---- */
        $tax = $taxes[ $label ];
        // Hours: adopt the existing term's spelling when it represents the same number
        // (e.g. keep term "1" rather than churning every product to a new "1.0" term).
        if ( 'credit_hours' === $field && ! empty( $desired ) ) {
            $existing_terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false ) );
            if ( ! is_wp_error( $existing_terms ) ) {
                foreach ( $desired as $di => $dv ) {
                    foreach ( $existing_terms as $t ) {
                        if ( is_numeric( $t->name ) && abs( (float) $t->name - (float) $dv ) < 0.001 ) {
                            $desired[ $di ] = $t->name; break;
                        }
                    }
                }
            }
        }
        // Revision Date: never clear an existing date because the course field is empty.
        if ( 'revision_date' === $field && empty( $desired ) ) continue;

        $current = wp_get_object_terms( $product_id, $tax, array( 'fields' => 'names' ) );
        if ( is_wp_error( $current ) ) continue;
        sort( $current ); $d = $desired; sort( $d );
        if ( $current === $d ) continue;

        if ( empty( $desired ) ) {
            $changes[] = "$label: cleared (" . count( $current ) . ' terms removed)';
        } elseif ( empty( $current ) ) {
            $changes[] = "$label: set " . ( count( $desired ) === 1 ? '"' . $desired[0] . '"' : count( $desired ) . ' terms' ) . ' (was empty)';
        } elseif ( count( $desired ) === 1 && count( $current ) === 1 ) {
            $changes[] = "$label: \"{$current[0]}\" -> \"{$desired[0]}\"";
        } else {
            $add = count( array_diff( $d, $current ) ); $rem = count( array_diff( $current, $d ) );
            $changes[] = "$label: +$add / -$rem terms";
        }
        if ( ! $dry ) {
            wp_set_object_terms( $product_id, $desired, $tax );
            $key = sanitize_title( $tax );
            if ( empty( $desired ) ) {
                if ( isset( $meta[ $key ] ) ) { unset( $meta[ $key ] ); $meta_changed = true; }
            } elseif ( ! isset( $meta[ $key ] ) ) {
                $meta[ $key ] = array( 'name' => $tax, 'value' => '', 'position' => count( $meta ),
                    'is_visible' => 1, 'is_variation' => 0, 'is_taxonomy' => 1 );
                $meta_changed = true;
            }
        }
    }
    if ( ! $dry && $meta_changed ) update_post_meta( $product_id, '_product_attributes', $meta );
    if ( ! $dry && $changes ) {
        if ( function_exists( 'wc_delete_product_transients' ) ) wc_delete_product_transients( $product_id );
        clean_post_cache( $product_id );
    }
    return $changes;
}

/* Auto-sync when a course is saved (ACF fields save at priority 10). */
add_action( 'acf/save_post', function ( $post_id ) {
    if ( get_post_type( $post_id ) !== 'sfwd-courses' ) return;
    $map = hisc_sync_course_products();
    if ( empty( $map[ (int) $post_id ] ) ) return;
    foreach ( $map[ (int) $post_id ] as $product ) {
        hisc_sync_product( $product->ID, (int) $post_id, false );
    }
}, 20 );

/* Tools page: full-catalog preview + sync */
add_action( 'admin_menu', function () {
    add_management_page( 'HISC Product Sync', 'HISC Product Sync', 'manage_options', 'hisc-product-sync', 'hisc_sync_page' );
} );

function hisc_sync_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( ! function_exists( 'wc_get_attribute_taxonomies' ) || ! function_exists( 'get_field' ) ) {
        echo '<div class="wrap"><p style="color:red">WooCommerce and ACF must be active.</p></div>'; return;
    }
    $apply = isset( $_POST['hisc_apply'] ) && check_admin_referer( 'hisc_psync' );
    echo '<div class="wrap"><h1>HISC Product Sync ' . ( $apply ? '&mdash; APPLIED' : '&mdash; PREVIEW' ) . '</h1>';
    echo '<p>Compares each product&rsquo;s attributes (Contact Hours, Revision Date, approved-state lists) against its course&rsquo;s CE data. Products update automatically whenever a course is saved; use this page to catch up the whole catalog. CE Format is not touched. Multi-course products (bundles) are skipped.</p>';
    echo '<table class="widefat striped"><thead><tr><th>Product / Course</th><th>Changes</th></tr></thead><tbody>';
    $n_changed = 0; $n_ok = 0;
    foreach ( hisc_sync_course_products() as $course_id => $products ) {
        foreach ( $products as $product ) {
            $changes = hisc_sync_product( $product->ID, $course_id, ! $apply );
            if ( empty( $changes ) ) { $n_ok++; continue; }
            $n_changed++;
            printf( '<tr><td>%s</td><td style="font-size:12px">%s</td></tr>',
                esc_html( $product->post_title ), esc_html( implode( ' &nbsp;|&nbsp; ', $changes ) ) );
        }
    }
    echo '</tbody></table>';
    printf( '<p><strong>%d product(s) %s, %d already in sync.</strong></p>', $n_changed, $apply ? 'updated' : 'need changes', $n_ok );
    if ( ! $apply && $n_changed ) {
        echo '<form method="post">'; wp_nonce_field( 'hisc_psync' );
        echo '<p><button class="button button-primary" name="hisc_apply" value="1">Apply &mdash; sync all listed products</button></p></form>';
    }
    echo '</div>';
}

/* ===================== New Live Event Creator ===================== */
/* Tools -> HISC New Live Event: builds a live event course from a catalog
   course — copies its CE data, creates the eval lesson with the master eval,
   assigns the certificate, no quiz. */

function hisc_live_ce_fields() {
    return array( 'credit_hours','revision_date','ancc_expiration','learning_outcome',
        'pt_approval_number','pt_ccus','pt_expiration','ot_approval_number','ot_ceus','ot_expiration',
        'tsha_id','slp_clock_hours','slp_expiration',
        'rn_states','sw_states','ccm_states','pt_states','ot_states','slp_states','rd_states' );
}

function hisc_live_master_eval_id() {
    if ( ! class_exists( 'GFAPI' ) ) return 0;
    foreach ( GFAPI::get_forms() as $f ) {
        if ( ! empty( $f['cssClass'] ) && strpos( $f['cssClass'], 'hisc-master-eval' ) !== false ) return (int) $f['id'];
    }
    return 0;
}

add_action( 'admin_menu', function () {
    add_management_page( 'HISC New Live Event', 'HISC New Live Event', 'manage_options', 'hisc-new-live-event', 'hisc_live_page' );
} );

function hisc_live_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( ! function_exists( 'learndash_update_setting' ) || ! function_exists( 'get_field' ) ) {
        echo '<div class="wrap"><p style="color:red">LearnDash and ACF must be active.</p></div>'; return;
    }
    $eval_id = hisc_live_master_eval_id();
    echo '<div class="wrap"><h1>New Live Event Course</h1>';
    if ( ! $eval_id ) { echo '<p style="color:red">Master eval form (cssClass hisc-master-eval) not found in Gravity Forms.</p></div>'; return; }

    if ( isset( $_POST['hisc_create'] ) && check_admin_referer( 'hisc_live' ) ) {
        $src      = absint( $_POST['hisc_src'] );
        $delivery = in_array( $_POST['hisc_delivery'], array( 'live_webinar', 'in_person' ), true ) ? $_POST['hisc_delivery'] : 'in_person';
        $date     = sanitize_text_field( wp_unslash( $_POST['hisc_date'] ) );
        $location = sanitize_text_field( wp_unslash( $_POST['hisc_location'] ) );
        $cert     = absint( $_POST['hisc_cert'] );

        if ( $src && $date && ( $location || 'live_webinar' === $delivery ) ) {
            $date_disp = $date;
            $ts = strtotime( $date );
            if ( $ts ) $date_disp = date_i18n( 'n/j/y', $ts );
            // in-person: date + location; webinar: date only
            $title = '"' . get_the_title( $src ) . '" on ' . $date_disp;
            if ( 'in_person' === $delivery && $location ) $title .= ' at ' . $location;

            $course_id = wp_insert_post( array( 'post_type' => 'sfwd-courses', 'post_title' => $title, 'post_status' => 'publish' ) );
            if ( $course_id && ! is_wp_error( $course_id ) ) {
                // copy CE data from the catalog course
                foreach ( hisc_live_ce_fields() as $f ) {
                    $v = get_field( $f, $src );
                    if ( $v !== null && $v !== '' && $v !== false ) update_field( 'field_hisc_' . $f, $v, $course_id );
                }
                $disc = get_field( 'disciplines', $src );
                if ( $disc ) update_field( 'field_hisc_disciplines', $disc, $course_id );
                $obj = get_field( 'objectives', $src );
                if ( $obj ) update_field( 'field_hisc_objectives', $obj, $course_id );
                update_field( 'field_hisc_ce_delivery', $delivery, $course_id );

                // course settings: closed (group access), master certificate
                learndash_update_setting( $course_id, 'course_price_type', 'closed' );
                if ( $cert ) learndash_update_setting( $course_id, 'certificate', $cert );

                // eval lesson with master eval embed
                $lesson_id = wp_insert_post( array(
                    'post_type' => 'sfwd-lessons', 'post_status' => 'publish',
                    'post_title' => 'Evaluation – ' . get_the_title( $src ),
                    'post_content' => '[gravityform id="' . $eval_id . '" title="false" description="true" ajax="true"]',
                ) );
                if ( $lesson_id && ! is_wp_error( $lesson_id ) ) {
                    update_post_meta( $lesson_id, 'course_id', $course_id );
                    learndash_update_setting( $lesson_id, 'course', $course_id );
                    if ( function_exists( 'learndash_course_set_steps' ) ) {
                        learndash_course_set_steps( $course_id, array(
                            'sfwd-lessons' => array( $lesson_id => array( 'sfwd-topic' => array(), 'sfwd-quiz' => array() ) ),
                            'sfwd-quiz'    => array(),
                        ) );
                    }
                }
                printf( '<div class="notice notice-success"><p><strong>Created:</strong> %s &nbsp; <a href="%s">Edit course</a> &nbsp;|&nbsp; <a href="%s" target="_blank">View</a></p><p>Next: attach the LearnDash group for this event, then test the eval + certificate as a group member.</p></div>',
                    esc_html( $title ), esc_url( get_edit_post_link( $course_id ) ), esc_url( get_permalink( $course_id ) ) );
            } else {
                echo '<div class="notice notice-error"><p>Could not create the course.</p></div>';
            }
        } else {
            echo '<div class="notice notice-error"><p>Catalog course, date, and location (for in-person) are required.</p></div>';
        }
    }

    $courses = get_posts( array( 'post_type' => 'sfwd-courses', 'numberposts' => -1, 'post_status' => 'publish', 'orderby' => 'title', 'order' => 'ASC' ) );
    $certs   = get_posts( array( 'post_type' => 'sfwd-certificates', 'numberposts' => -1, 'post_status' => 'publish' ) );
    echo '<form method="post">'; wp_nonce_field( 'hisc_live' );
    echo '<table class="form-table">';
    echo '<tr><th>Catalog course</th><td><select name="hisc_src" style="max-width:600px">';
    foreach ( $courses as $c ) {
        if ( preg_match( '/\son\s\d{1,2}\/\d{1,2}\/\d{2}/', $c->post_title ) ) continue; // skip existing event courses
        printf( '<option value="%d">%s</option>', $c->ID, esc_html( $c->post_title ) );
    }
    echo '</select><p class="description">CE data, statements, objectives, and outcome are copied from this course.</p></td></tr>';
    echo '<tr><th>Delivery</th><td><select name="hisc_delivery"><option value="in_person">Live In Person</option><option value="live_webinar">Live Webinar</option></select></td></tr>';
    echo '<tr><th>Event date</th><td><input type="date" name="hisc_date" required></td></tr>';
    echo '<tr><th>Location</th><td><input type="text" name="hisc_location" style="width:400px" placeholder="e.g. Encompass Health Katy (leave blank for webinars)"></td></tr>';
    echo '<tr><th>Certificate</th><td><select name="hisc_cert">';
    foreach ( $certs as $c ) printf( '<option value="%d" %s>%s</option>', $c->ID, ( stripos( $c->post_title, 'master' ) !== false ? 'selected' : '' ), esc_html( $c->post_title ) );
    echo '</select></td></tr>';
    echo '</table><p><button class="button button-primary" name="hisc_create" value="1">Create live event course</button></p></form></div>';
}

/* ===================== Live Course Matrix (group-order forms) ===================== */
/* Public endpoint serving the course/approval matrix built from course fields.
   Consumed by hisc-course-filter.js embedded in the internal + external group
   order forms. Cached; cache busts whenever a course or product is saved. */

function hisc_course_matrix() {
    $cached = get_transient( 'hisc_course_matrix' );
    if ( is_array( $cached ) ) return $cached;

    $out = array();
    $map = hisc_sync_course_products(); // single-course products only (bundles excluded)
    foreach ( $map as $course_id => $products ) {
        $product = $products[0];
        if ( get_post_status( $course_id ) !== 'publish' ) continue;

        // category: first product category that isn't "All Courses"
        $cat = '';
        $terms = get_the_terms( $product->ID, 'product_cat' );
        if ( is_array( $terms ) ) {
            foreach ( $terms as $t ) {
                if ( strtolower( $t->name ) !== 'all courses' ) { $cat = $t->name; break; }
            }
        }

        $hours = get_field( 'credit_hours', $course_id );
        $h = $hours ? rtrim( rtrim( number_format( (float) $hours, 1 ), '0' ), '.' ) : '1';

        $a = array();
        foreach ( array( 'rn' => 'rn_states', 'sw' => 'sw_states', 'cm' => 'ccm_states',
                         'pt' => 'pt_states', 'ot' => 'ot_states', 'slp' => 'slp_states',
                         'rd' => 'rd_states' ) as $key => $field ) {
            $v = trim( (string) get_field( $field, $course_id ) );
            if ( $v === '' ) continue;
            $states = array_values( array_filter( array_map( 'trim', explode( ',', $v ) ) ) );
            if ( empty( $states ) ) continue;
            $a[ $key ] = ( count( $states ) >= 48 ) ? 'ALL' : $states;
        }
        if ( empty( $a ) ) continue;

        $row = array( 'n' => $product->post_title, 'h' => $h, 'c' => $cat ?: 'Other', 'a' => $a );
        if ( get_field( 'live_available', $course_id ) ) $row['l'] = 1; // available as live presentation
        $out[] = $row;
    }
    usort( $out, function ( $x, $y ) { return strcasecmp( $x['n'], $y['n'] ); } );
    set_transient( 'hisc_course_matrix', $out, 12 * HOUR_IN_SECONDS );
    return $out;
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'hisc/v1', '/course-matrix', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => function () { return rest_ensure_response( hisc_course_matrix() ); },
    ) );
} );

/* bust the matrix cache when courses or products change */
add_action( 'acf/save_post', function ( $post_id ) {
    if ( get_post_type( $post_id ) === 'sfwd-courses' ) delete_transient( 'hisc_course_matrix' );
}, 30 );
add_action( 'save_post_product', function () { delete_transient( 'hisc_course_matrix' ); } );
