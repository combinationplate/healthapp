/**
 * HISC Group Order Course Filter — shared by internal + external forms.
 * Reads config from window.HISC_FILTER = { discipline: N, state: N, course: N }
 * Fetches the live course matrix from /wp-json/hisc/v1/course-matrix
 * (built from each course's CE Data fields — never hand-updated).
 *
 * v2.3.4 changes:
 *  - SW accreditation notice now fires for New York only (NJ accepts ASWB ACE,
 *    N.J.A.C. 13:44G-6.4(c)(2), amended eff. 4/15/2024).
 *  - A therapy discipline with zero approved courses in the chosen state no
 *    longer blanks the whole list: it is excluded from filtering (matching the
 *    notice text "Courses shown are available for your other selected
 *    disciplines"). Only when EVERY selected discipline is blocked does the
 *    list stay empty, with a contact-us notice.
 */
if (window.__HISC_FILTER_LOADED) { /* already loaded via plugin enqueue */ } else {
window.__HISC_FILTER_LOADED = true;
document.addEventListener("DOMContentLoaded", function () {
  var cfg = window.HISC_FILTER || {};
  var DISCIPLINE_FIELD_ID = cfg.discipline;
  var STATE_FIELD_ID = cfg.state;
  var COURSE_FIELD_ID = cfg.course;
  if (!COURSE_FIELD_ID) return; // discipline + state fields are auto-detected

  var COURSES = [];
  var CAT_ORDER = [
    "Alzheimer's Disease", "Care Transitions", "Ethics", "Family Caregivers",
    "Organizational Training", "Patient Safety", "Psycho-Social Care",
    "Stroke", "Veterans", "Wellness"
  ];

  var DISC_MAP = {
    "Nurse": "rn", "Social Worker": "sw", "Case Manager": "cm", "Counselor": "lpc",
    "Physical Therapist": "pt", "Occupational Therapist": "ot", "Speech": "slp", "Dietitian": "rd"
  };

  var THERAPY_LABELS = { pt: "Physical Therapy", ot: "Occupational Therapy", slp: "Speech-Language Pathology" };

  var form = document.querySelector("[id^='gform_wrapper_']");
  if (!form) return;

  function findSelect(fieldId) {
    var selectors = [".gfield--id-" + fieldId + " select", "#field_" + fieldId + " select"];
    var wrappers = document.querySelectorAll("[id^='gform_wrapper_']");
    wrappers.forEach(function (w) {
      var formId = w.id.replace("gform_wrapper_", "");
      selectors.push("#input_" + formId + "_" + fieldId);
    });
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (el && el.tagName === "SELECT") return el;
    }
    return null;
  }

  function labelFor(cb) {
    return cb.closest("label") || document.querySelector("label[for='" + cb.id + "']");
  }

  // Document-scoped lookup by field id (this is what worked historically).
  function findCheckboxes(fieldId) {
    if (fieldId) {
      var sels = [".gfield--id-" + fieldId + " input[type='checkbox']", "#field_" + fieldId + " input[type='checkbox']"];
      var wrappers = document.querySelectorAll("[id^='gform_wrapper_']");
      wrappers.forEach(function (w) {
        var formId = w.id.replace("gform_wrapper_", "");
        sels.push("#input_" + formId + "_" + fieldId + " input[type='checkbox']");
      });
      for (var i = 0; i < sels.length; i++) {
        var els = document.querySelectorAll(sels[i]);
        if (els.length > 0) return els;
      }
    }
    // fallback: any checkbox in the document whose label matches a discipline keyword
    var out = [];
    document.querySelectorAll("input[type='checkbox']").forEach(function (cb) {
      var label = labelFor(cb);
      if (!label) return;
      var text = label.textContent || "";
      for (var keyword in DISC_MAP) { if (text.indexOf(keyword) !== -1) { out.push(cb); return; } }
    });
    return out;
  }

  function getSelectedDisciplines() {
    var selected = [];
    findCheckboxes(DISCIPLINE_FIELD_ID).forEach(function (cb) {
      if (!cb.checked) return;
      var text = (labelFor(cb) || {}).textContent || "";
      for (var keyword in DISC_MAP) {
        if (text.indexOf(keyword) !== -1) {
          if (selected.indexOf(DISC_MAP[keyword]) === -1) selected.push(DISC_MAP[keyword]);
          break;
        }
      }
    });
    return selected;
  }

  function findStateSelect() {
    var sel = STATE_FIELD_ID ? findSelect(STATE_FIELD_ID) : null;
    if (sel) return sel;
    var all = form.querySelectorAll("select");
    for (var i = 0; i < all.length; i++) {
      var opts = Array.prototype.map.call(all[i].options, function (o) { return o.textContent; });
      if (opts.indexOf("Alabama") !== -1 && opts.indexOf("Wyoming") !== -1) return all[i];
    }
    return null;
  }

  function getSelectedState() {
    var sel = findStateSelect();
    return sel ? sel.value : "";
  }

  // Course Type radios ("Take Home/Online CE" vs "Live CE ...") — auto-detected by label text.
  function findCourseTypeRadios() {
    var out = [];
    document.querySelectorAll("input[type='radio']").forEach(function (r) {
      var label = labelFor(r);
      var text = label ? (label.textContent || "") : (r.value || "");
      if (/live\s*ce/i.test(text) || /take\s*home/i.test(text)) out.push(r);
    });
    return out;
  }

  function isLiveSelected() {
    var radios = findCourseTypeRadios();
    for (var i = 0; i < radios.length; i++) {
      if (!radios[i].checked) continue;
      var label = labelFor(radios[i]);
      var text = label ? (label.textContent || "") : (radios[i].value || "");
      if (/live\s*ce/i.test(text)) return true;
    }
    return false;
  }

  /* Therapy disciplines with NO approved courses at all in the chosen state.
     These get a warning notice and are excluded from filtering, so the list
     can still serve the other selected disciplines. */
  function therapyBlocked(disciplines, state) {
    if (!state) return [];
    var blocked = [];
    disciplines.forEach(function (d) {
      if (d !== "pt" && d !== "ot" && d !== "slp") return;
      var anyApproved = COURSES.some(function (c) {
        var a = c.a[d];
        return a === "ALL" || (Array.isArray(a) && a.indexOf(state) !== -1);
      });
      if (!anyApproved) blocked.push(d);
    });
    return blocked;
  }

  function isCourseApproved(course, disciplines, state) {
    if (disciplines.length === 0) return true;
    for (var i = 0; i < disciplines.length; i++) {
      var disc = disciplines[i];
      if (disc === "lpc") continue; // LPCs approved everywhere
      var approval = course.a[disc];
      if (!approval) return false;          // no approval for this discipline at all
      if (approval === "ALL") continue;
      if (state && approval.indexOf(state) === -1) return false; // state narrows further once chosen
    }
    return true;
  }

  function updateCourseDropdown() {
    var courseSel = findSelect(COURSE_FIELD_ID);
    if (!courseSel) return;
    var disciplines = getSelectedDisciplines();
    var state = getSelectedState();
    var currentVal = courseSel.value;

    // Live CE narrows to courses flagged "Available as Live Presentation".
    // Guard: only applies once at least one course carries the flag, so the
    // form keeps working unchanged until the live_available field is seeded.
    var live = isLiveSelected() && COURSES.some(function (c) { return c.l; });

    var blocked = therapyBlocked(disciplines, state);
    var effective = disciplines.filter(function (d) { return blocked.indexOf(d) === -1; });
    // Every selected discipline is blocked in this state: nothing to offer.
    var allBlocked = disciplines.length > 0 && blocked.length > 0 && effective.length === 0;

    var filtered = allBlocked ? [] : COURSES.filter(function (c) {
      if (live && !c.l) return false;
      return isCourseApproved(c, effective, state);
    });

    var grouped = {};
    filtered.forEach(function (c) { (grouped[c.c] = grouped[c.c] || []).push(c); });

    // known categories first, any new ones appended alphabetically
    var cats = CAT_ORDER.filter(function (c) { return grouped[c]; });
    Object.keys(grouped).sort().forEach(function (c) { if (cats.indexOf(c) === -1) cats.push(c); });

    courseSel.innerHTML = "";
    var defaultOpt = document.createElement("option");
    defaultOpt.value = "";
    defaultOpt.textContent = filtered.length === COURSES.length
      ? "Select a course..."
      : filtered.length + " of " + COURSES.length + " courses match your selections";
    courseSel.appendChild(defaultOpt);

    cats.forEach(function (cat) {
      var optgroup = document.createElement("optgroup");
      optgroup.label = cat;
      grouped[cat].forEach(function (c) {
        var opt = document.createElement("option");
        opt.value = c.n;
        var label = c.n + " (" + c.h + " hr)";
        var tags = [];
        if (c.a.pt) tags.push("PT");
        if (c.a.ot) tags.push("OT");
        if (c.a.slp) tags.push("SLP");
        if (tags.length > 0) label += " [" + tags.join("/") + "]";
        opt.textContent = label;
        if (c.n === currentVal) opt.selected = true;
        optgroup.appendChild(opt);
      });
      courseSel.appendChild(optgroup);
    });

    updateNotices(disciplines, state, filtered, live, blocked, allBlocked);

    if (window.jQuery) {
      jQuery(courseSel).trigger("change");
      if (jQuery(courseSel).data("chosen")) jQuery(courseSel).trigger("chosen:updated");
      if (jQuery(courseSel).data("select2")) jQuery(courseSel).trigger("change.select2");
    }
  }

  function updateNotices(disciplines, state, filtered, live, blocked, allBlocked) {
    form.querySelectorAll(".hisc-notice").forEach(function (el) { el.remove(); });
    var notices = [];

    if (live) {
      notices.push({ type: "info", text: "Showing only courses available as live presentations. Switch to Take Home/Online CE to see the full catalog." });
    }

    // NY only: NJ accepts ASWB ACE providers (N.J.A.C. 13:44G-6.4(c)(2)).
    if (disciplines.indexOf("sw") !== -1 && state === "New York") {
      notices.push({ type: "warn", text: "H.I.S. Cornerstone is not currently accredited for social workers in " + state + ". Courses will still be available for all other selected disciplines." });
    }

    var therapySelected = disciplines.some(function (d) { return d === "pt" || d === "ot" || d === "slp"; });
    if (blocked.length > 0) {
      var names = blocked.map(function (d) { return THERAPY_LABELS[d]; }).join(" and ");
      var verb = blocked.length > 1 ? "are" : "is";
      if (allBlocked) {
        notices.push({ type: "warn", text: names + " " + verb + " not currently approved in " + state + ", so no courses match this selection. Please contact us at hello@hiscornerstone.com and we will help you find an option for your group." });
      } else {
        notices.push({ type: "warn", text: names + " " + verb + " not currently approved in " + state + ". Courses shown are available for your other selected disciplines." });
      }
    } else if (therapySelected && state && filtered.length < COURSES.length) {
      notices.push({ type: "info", text: "Therapy discipline approvals vary by course. The list below shows only courses approved for all your selected disciplines in " + state + "." });
    }

    if (notices.length > 0) {
      var courseSel2 = findSelect(COURSE_FIELD_ID);
      if (!courseSel2) return;
      var wrapper = courseSel2.closest(".gfield");
      if (!wrapper) return;
      // Prefer the field's inner container, which is reliably full-width;
      // fall back to the field wrapper itself.
      var host = wrapper.querySelector(".ginput_container") || wrapper;
      notices.forEach(function (n) {
        var div = document.createElement("div");
        div.className = "hisc-notice hisc-notice-" + n.type;
        div.style.cssText = "display:block;box-sizing:border-box;width:100%;grid-column:1 / -1;padding:10px 14px;margin:0 0 12px;border-radius:6px;font-size:14px;line-height:1.5;" +
          (n.type === "warn"
            ? "background:#fef3cd;color:#856404;border-left:3px solid #ffc107;"
            : "background:#d1ecf1;color:#0c5460;border-left:3px solid #17a2b8;");
        div.textContent = n.text;
        host.insertBefore(div, host.firstChild);
      });
    }
  }

  function attachListeners() {
    var boxes = findCheckboxes(DISCIPLINE_FIELD_ID);
    boxes.forEach(function (cb) { cb.addEventListener("change", updateCourseDropdown); });
    var stateSel = findStateSelect();
    if (stateSel) stateSel.addEventListener("change", updateCourseDropdown);
    var typeRadios = findCourseTypeRadios();
    typeRadios.forEach(function (r) { r.addEventListener("change", updateCourseDropdown); });
    if (window.location.search.indexOf("hisc_debug") !== -1) {
      console.log("[HISC filter] courses:", COURSES.length,
        "| live-flagged:", COURSES.filter(function (c) { return c.l; }).length,
        "| discipline boxes found:", boxes.length,
        "| state select found:", !!stateSel,
        "| course type radios found:", typeRadios.length,
        "| course select found:", !!findSelect(COURSE_FIELD_ID));
    }
    updateCourseDropdown();
  }

  fetch("/wp-json/hisc/v1/course-matrix")
    .then(function (r) { return r.json(); })
    .then(function (data) {
      COURSES = Array.isArray(data) ? data : [];
      setTimeout(attachListeners, 300);
    })
    .catch(function () { /* endpoint unavailable: dropdown stays as authored in the form */ });
});
}
