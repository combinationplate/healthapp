<?php
/**
 * HISC Group QuickJoin — module of HIS Cornerstone CE Toolkit (since v2.3).
 *
 * QR flyer -> landing page (?hisc_join=CODE) -> one button -> account
 * found-or-created -> enrolled in the LearnDash group -> logged in ->
 * redirected into the course.
 *
 * Design spec: project doc claude/HISC_Group_QuickJoin_Strategy.md
 *  - New email: silent account creation (no password, no email), instant login.
 *  - Existing email: enrolled immediately, then a one-time login link is
 *    EMAILED (public QR = anyone can type any email, so ownership must be
 *    proven before handing over an existing account).
 *  - Flat 200 cap per group (abuse insurance only), expiry, regenerate.
 *  - GET is always side-effect free; enrollment fires only on human POST.
 *  - Uncanny Groups untouched: its registration codes remain the desktop path.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'HISC_QJ_DEFAULT_CAP', 200 );
define( 'HISC_QJ_TOKEN_TTL', 15 * MINUTE_IN_SECONDS );

/* ===================== helpers ===================== */

function hisc_qj_group_by_code( $code ) {
	$code = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $code ) );
	if ( strlen( $code ) < 20 ) return null;
	$ids = get_posts( array(
		'post_type'   => 'groups',
		'post_status' => 'publish',
		'numberposts' => 1,
		'meta_key'    => 'hisc_join_code',
		'meta_value'  => $code,
		'fields'      => 'ids',
	) );
	return $ids ? get_post( $ids[0] ) : null;
}

function hisc_qj_join_url( $group_id ) {
	$code = get_post_meta( $group_id, 'hisc_join_code', true );
	return $code ? add_query_arg( 'hisc_join', $code, home_url( '/' ) ) : '';
}

function hisc_qj_course_for_group( $group_id ) {
	if ( function_exists( 'learndash_group_enrolled_courses' ) ) {
		$courses = learndash_group_enrolled_courses( $group_id );
		if ( ! empty( $courses ) ) {
			$courses = array_values( array_map( 'intval', (array) $courses ) );
			return $courses[0];
		}
	}
	return 0;
}

function hisc_qj_redirect_target( $group_id ) {
	$course_id = hisc_qj_course_for_group( $group_id );
	$url = $course_id ? get_permalink( $course_id ) : '';
	return $url ? $url : home_url( '/' );
}

function hisc_qj_member_count( $group_id ) {
	if ( function_exists( 'learndash_get_groups_user_ids' ) ) {
		return count( (array) learndash_get_groups_user_ids( $group_id, true ) );
	}
	return 0;
}

function hisc_qj_cap( $group_id ) {
	$cap = (int) get_post_meta( $group_id, 'hisc_join_cap', true );
	return $cap > 0 ? $cap : HISC_QJ_DEFAULT_CAP;
}

function hisc_qj_expired( $group_id ) {
	$exp = (int) get_post_meta( $group_id, 'hisc_join_expires', true );
	return $exp > 0 && time() > $exp;
}

/** Existing members may always re-enter (even at cap); new joins respect the cap. */
function hisc_qj_can_enroll( $group_id, $user_id ) {
	if ( $user_id && function_exists( 'learndash_is_user_in_group' ) && learndash_is_user_in_group( $user_id, $group_id ) ) {
		return true;
	}
	return hisc_qj_member_count( $group_id ) < hisc_qj_cap( $group_id );
}

function hisc_qj_generate_code( $group_id ) {
	update_post_meta( $group_id, 'hisc_join_code', bin2hex( random_bytes( 16 ) ) );
}

/** The human login page: the branded My Account login, never bare wp-login.php.
    Order: HISC_QJ_LOGIN_URL constant (wp-config.php) > WooCommerce's configured
    My Account page > /my-account/ (verified to exist on hiscornerstone.com). */
function hisc_qj_login_page_url( $redirect = '' ) {
	$url = '';
	if ( defined( 'HISC_QJ_LOGIN_URL' ) && HISC_QJ_LOGIN_URL ) {
		$url = HISC_QJ_LOGIN_URL;
	} elseif ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = (string) wc_get_page_permalink( 'myaccount' );
	}
	if ( '' === $url || false !== strpos( $url, 'wp-login.php' ) ) {
		$url = home_url( '/my-account/' );
	}
	return $redirect ? add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url ) : $url;
}

/* Honor redirect_to on the Woo My Account login, so "log in with password"
   still lands the learner inside the course instead of on the account page. */
add_filter( 'woocommerce_login_redirect', function ( $redirect, $user ) {
	if ( ! empty( $_REQUEST['redirect_to'] ) ) {
		$to = wp_validate_redirect( wp_unslash( (string) $_REQUEST['redirect_to'] ), '' );
		if ( $to ) return $to;
	}
	return $redirect;
}, 10, 2 );

/** Light per-IP throttle: 60 POSTs / 10 minutes (a whole training room may
    share one NAT'd Wi-Fi IP, so the ceiling is deliberately generous). */
function hisc_qj_throttle_ok() {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
	$key = 'hisc_qj_ip_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 60 ) return false;
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
	return true;
}

/* ===================== auto join-code on group creation ===================== */
/* Fires for admin-created AND REST-created (Zapier) groups. Expiry default is
   set only when the code is first created, so clearing expiry in the metabox
   ("never expires") is respected on later saves. */

add_action( 'save_post_groups', function ( $post_id, $post ) {
	if ( wp_is_post_revision( $post_id ) || 'publish' !== $post->post_status ) return;
	if ( ! get_post_meta( $post_id, 'hisc_join_code', true ) ) {
		hisc_qj_generate_code( $post_id );
		update_post_meta( $post_id, 'hisc_join_expires', time() + YEAR_IN_SECONDS );
	}
}, 10, 2 );

/* ===================== REST: join URL for Zapier ===================== */
/* GET /wp-json/hisc/v1/group-join-url?group_id=123
   Authenticated exactly like the LearnDash group-creation call (Application
   Password on the automation user). Lazily creates the code if the Zap fetches
   in the same instant the group was created. */

add_action( 'rest_api_init', function () {
	register_rest_route( 'hisc/v1', '/group-join-url', array(
		'methods'             => 'GET',
		'permission_callback' => function ( $req ) {
			$gid = absint( $req['group_id'] );
			if ( ! $gid ) return false;
			/* Admins (incl. the Zapier automation user) always pass. The edit_post
			   fallback covers non-admin roles that hold LearnDash's custom group
			   capabilities - LD registers 'groups' with its own caps, so edit_post
			   alone can deny users who are legitimately allowed to manage groups. */
			return current_user_can( 'manage_options' ) || current_user_can( 'edit_post', $gid );
		},
		'args'                => array( 'group_id' => array( 'required' => true ) ),
		'callback'            => function ( $req ) {
			$gid = absint( $req['group_id'] );
			if ( ! $gid || 'groups' !== get_post_type( $gid ) ) {
				return new WP_Error( 'hisc_not_group', 'Not a LearnDash group.', array( 'status' => 404 ) );
			}
			if ( ! get_post_meta( $gid, 'hisc_join_code', true ) ) {
				hisc_qj_generate_code( $gid );
				update_post_meta( $gid, 'hisc_join_expires', time() + YEAR_IN_SECONDS );
			}
			return rest_ensure_response( array(
				'group_id' => $gid,
				'join_url' => hisc_qj_join_url( $gid ),
				'expires'  => (int) get_post_meta( $gid, 'hisc_join_expires', true ),
				'cap'      => hisc_qj_cap( $gid ),
				'members'  => hisc_qj_member_count( $gid ),
			) );
		},
	) );
} );

/* ===================== front-end routing ===================== */

/* wp_loaded (not init): LearnDash registers its post types at init 10, and the
   handlers below need working sfwd-courses permalinks. */
add_action( 'wp_loaded', function () {
	if ( isset( $_REQUEST['hisc_join_login'] ) ) hisc_qj_handle_magic_login();
	if ( isset( $_REQUEST['hisc_join'] ) && ! is_admin() ) hisc_qj_handle_join();
	if ( isset( $_GET['hisc_qj_dismiss'] ) && is_user_logged_in()
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['hisc_qj_dismiss'] ) ), 'hisc_qj_dismiss' ) ) {
		delete_user_meta( get_current_user_id(), 'hisc_qj_pw_notice' );
		wp_safe_redirect( remove_query_arg( 'hisc_qj_dismiss' ) );
		exit;
	}
} );

/* ===================== magic login (existing-account branch) ===================== */
/* Same machinery as the proven pulse-connect flow: single-use token, 15-min TTL,
   logs out a different user on a shared device, silent homepage redirect when
   expired/used. Key prefix hisc_login_ (distinct from pulse_login_). */

function hisc_qj_handle_magic_login() {
	nocache_headers();
	$token = preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_REQUEST['hisc_join_login'] ) );
	$key   = 'hisc_login_' . hash( 'sha256', $token );
	$data  = strlen( $token ) === 64 ? get_transient( $key ) : false;
	if ( ! is_array( $data ) || empty( $data['user_id'] ) ) {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	/* GET renders a confirm button and consumes NOTHING - corporate email
	   scanners (Outlook SafeLinks etc.) prefetch links and would otherwise
	   burn the single-use token before the learner taps it. */
	if ( 'POST' !== strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) || empty( $_POST['hisc_qj_login_go'] ) ) {
		hisc_qj_login_confirm_page( $token );
	}

	delete_transient( $key ); // single use - consumed only on the human POST
	$user = get_user_by( 'id', (int) $data['user_id'] );
	if ( ! $user ) { wp_safe_redirect( home_url( '/' ) ); exit; }
	/* Deferred name backfill: applied only now that inbox ownership is proven,
	   and only if BOTH names are currently empty (never overwrite a customer). */
	if ( ! empty( $data['first'] ) && ! empty( $data['last'] )
		&& '' === trim( (string) $user->first_name ) && '' === trim( (string) $user->last_name ) ) {
		wp_update_user( array(
			'ID'           => $user->ID,
			'first_name'   => $data['first'],
			'last_name'    => $data['last'],
			'display_name' => trim( $data['first'] . ' ' . $data['last'] ),
		) );
	}
	if ( is_user_logged_in() && get_current_user_id() !== (int) $user->ID ) wp_logout();
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, true );
	do_action( 'wp_login', $user->user_login, $user );
	wp_safe_redirect( ! empty( $data['redirect'] ) ? $data['redirect'] : home_url( '/' ) );
	exit;
}

/** Tiny interstitial so the emailed link is a pure GET; the button POSTs. */
function hisc_qj_login_confirm_page( $token ) {
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	$action = esc_url( add_query_arg( 'hisc_join_login', $token, home_url( '/' ) ) );
	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Continue to your course</title><style>'
		. 'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#f2f6f6;color:#1a2b2b;display:flex;flex-direction:column;min-height:100vh;margin:0}'
		. '.hd{background:linear-gradient(135deg,#0e7c7b,#0a5c5b);color:#fff;padding:22px 18px;text-align:center;font-size:15px;letter-spacing:.5px}'
		. '.wrap{flex:1;display:flex;justify-content:center;padding:22px 14px}'
		. '.card{background:#fff;border-radius:14px;box-shadow:0 2px 14px rgba(10,60,60,.10);max-width:460px;width:100%;padding:26px 22px;height:fit-content}'
		. 'h1{font-size:21px;margin:0 0 8px}p{color:#4a5c5c;font-size:14px;line-height:1.5}'
		. '.btn{display:block;width:100%;margin-top:18px;padding:14px;font-size:17px;font-weight:700;color:#fff;background:#0e7c7b;border:0;border-radius:9px;cursor:pointer}'
		. '</style></head><body><div class="hd">H.I.S. Cornerstone Continuing Education</div><div class="wrap"><div class="card">'
		. '<h1>You are one tap away</h1><p>Press the button to sign in and go straight into your course.</p>'
		. '<form method="post" action="' . $action . '"><input type="hidden" name="hisc_qj_login_go" value="1">'
		. '<button class="btn" type="submit">Continue to my course</button></form>'
		. '</div></div></body></html>';
	exit;
}

function hisc_qj_send_login_email( $user, $group_id, $first = '', $last = '' ) {
	$token = bin2hex( random_bytes( 32 ) );
	set_transient(
		'hisc_login_' . hash( 'sha256', $token ),
		array(
			'user_id'  => (int) $user->ID,
			'redirect' => hisc_qj_redirect_target( $group_id ),
			'first'    => $first,
			'last'     => $last,
		),
		HISC_QJ_TOKEN_TTL
	);
	$course_id = hisc_qj_course_for_group( $group_id );
	$course    = $course_id ? get_the_title( $course_id ) : get_the_title( $group_id );
	$link      = add_query_arg( 'hisc_join_login', $token, home_url( '/' ) );
	$first     = trim( (string) $user->first_name );
	$message   = 'Hi ' . ( $first !== '' ? $first : 'there' ) . ",\n\n"
		. "Good news: you already have an account with H.I.S. Cornerstone, so we kept it (your history and certificates stay together).\n\n"
		. "Tap this link to go straight into your course \"" . $course . "\":\n" . $link . "\n\n"
		. "The link works once and expires in 15 minutes. If it expires, scan the QR code again for a fresh one, or log in with your password at "
		. hisc_qj_login_page_url( hisc_qj_redirect_target( $group_id ) ) . "\n\n"
		. "H.I.S. Cornerstone Continuing Education\nQuality Education is the Cornerstone for Quality Care";
	wp_mail( $user->user_email, 'Your sign-in link - ' . $course, $message );
}

/* ===================== join landing + enroll (the core) ===================== */

function hisc_qj_handle_join() {
	nocache_headers();
	$group = hisc_qj_group_by_code( (string) wp_unslash( $_REQUEST['hisc_join'] ) );
	if ( ! $group ) hisc_qj_page( 'invalid' );
	$group_id  = (int) $group->ID;
	if ( hisc_qj_expired( $group_id ) ) hisc_qj_page( 'expired', $group );
	if ( ! hisc_qj_course_for_group( $group_id ) ) hisc_qj_page( 'invalid' ); // misconfigured group

	/* GET: pure render, zero side effects (link previews / prefetchers are safe) */
	if ( 'POST' !== strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) ) hisc_qj_page( 'form', $group );

	/* ---------- POST ---------- */
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hisc_qj_nonce'] ?? '' ) ), 'hisc_qj_' . $group_id ) ) {
		hisc_qj_page( 'form', $group, 'That page had been open a while - please press the button again.' );
	}
	if ( ! empty( $_POST['hisc_qj_website'] ) ) { wp_safe_redirect( home_url( '/' ) ); exit; } // honeypot
	if ( ! hisc_qj_throttle_ok() ) hisc_qj_page( 'form', $group, 'Too many attempts from this connection - please wait a few minutes and try again.' );

	/* "Continue as <current user>" button */
	if ( ! empty( $_POST['hisc_qj_continue'] ) && is_user_logged_in() ) {
		$uid = get_current_user_id();
		if ( ! hisc_qj_can_enroll( $group_id, $uid ) ) hisc_qj_page( 'full', $group );
		ld_update_group_access( $uid, $group_id );
		wp_safe_redirect( hisc_qj_redirect_target( $group_id ) );
		exit;
	}

	$resend = ! empty( $_POST['hisc_qj_resend'] );
	$first  = sanitize_text_field( wp_unslash( $_POST['hisc_qj_first'] ?? '' ) );
	$last   = sanitize_text_field( wp_unslash( $_POST['hisc_qj_last'] ?? '' ) );
	$email  = strtolower( sanitize_email( wp_unslash( $_POST['hisc_qj_email'] ?? '' ) ) );
	$email2 = strtolower( sanitize_email( wp_unslash( $_POST['hisc_qj_email2'] ?? '' ) ) );

	if ( ! is_email( $email ) ) hisc_qj_page( 'form', $group, 'Please enter a valid email address.' );
	if ( ! $resend ) {
		if ( '' === $first || '' === $last ) hisc_qj_page( 'form', $group, 'Please enter your first and last name as they appear on your professional license (this is what prints on your certificate).' );
		if ( $email !== $email2 ) hisc_qj_page( 'form', $group, 'The two email fields do not match - please double-check them.' );
	}

	$user = get_user_by( 'email', $email );

	if ( $user ) {
		/* EXISTING ACCOUNT: enroll first (a blocked email can never cost a seat),
		   then prove inbox ownership with a one-time login link. */
		if ( ! hisc_qj_can_enroll( $group_id, (int) $user->ID ) ) hisc_qj_page( 'full', $group );
		ld_update_group_access( (int) $user->ID, $group_id );
		/* Name backfill is DEFERRED to the magic-login handler: names typed on a
		   public QR page must not touch an existing account until the login link
		   proves the typist owns the inbox. */
		if ( is_user_logged_in() && get_current_user_id() === (int) $user->ID ) {
			wp_safe_redirect( hisc_qj_redirect_target( $group_id ) ); // already them - welcome back
			exit;
		}
		hisc_qj_send_login_email( $user, $group_id, $resend ? '' : $first, $resend ? '' : $last );
		hisc_qj_page( 'check_email', $group, '', $email );
	}

	/* NEW ACCOUNT: silent create (wp_insert_user sends no email), instant login. */
	if ( $resend ) hisc_qj_page( 'form', $group, 'We could not find an account for that email - please fill in the form below.' );
	if ( ! hisc_qj_can_enroll( $group_id, 0 ) ) hisc_qj_page( 'full', $group );

	$base = sanitize_user( (string) strstr( $email, '@', true ), true );
	if ( '' === $base ) $base = 'learner';
	$username = $base;
	$i = 1;
	while ( username_exists( $username ) ) $username = $base . ( ++$i );

	$uid = wp_insert_user( array(
		'user_login'   => $username,
		'user_email'   => $email,
		'user_pass'    => wp_generate_password( 24 ),
		'first_name'   => $first,
		'last_name'    => $last,
		'display_name' => trim( $first . ' ' . $last ) !== '' ? trim( $first . ' ' . $last ) : $username,
		'role'         => 'subscriber',
	) );
	if ( is_wp_error( $uid ) ) hisc_qj_page( 'form', $group, 'Something went wrong creating your account - please try again, or contact us and we will get you set up.' );

	update_user_meta( $uid, 'hisc_qj_group', $group_id );
	update_user_meta( $uid, 'hisc_qj_pw_notice', 1 ); // one-time "set a password" notice
	ld_update_group_access( $uid, $group_id );
	wp_set_current_user( $uid );
	wp_set_auth_cookie( $uid, true );
	do_action( 'wp_login', $username, get_user_by( 'id', $uid ) );
	wp_safe_redirect( hisc_qj_redirect_target( $group_id ) );
	exit;
}

/* ===================== landing page renderer ===================== */

function hisc_qj_page( $state, $group = null, $error = '', $email = '' ) {
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );

	$group_id     = $group ? (int) $group->ID : 0;
	$course_id    = $group_id ? hisc_qj_course_for_group( $group_id ) : 0;
	$course_title = $course_id ? get_the_title( $course_id ) : '';
	$group_title  = $group_id ? get_the_title( $group_id ) : '';
	$code         = $group_id ? get_post_meta( $group_id, 'hisc_join_code', true ) : '';
	$action       = $group_id ? esc_url( add_query_arg( 'hisc_join', $code, home_url( '/' ) ) ) : '';
	$site         = 'H.I.S. Cornerstone Continuing Education';

	echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
		. '<meta name="viewport" content="width=device-width, initial-scale=1">'
		. '<meta name="robots" content="noindex,nofollow">'
		. '<title>' . esc_html( $course_title !== '' ? $course_title : $site ) . '</title><style>'
		. '*{box-sizing:border-box;margin:0;padding:0}'
		. 'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#f2f6f6;color:#1a2b2b;min-height:100vh;display:flex;flex-direction:column}'
		. '.hd{background:linear-gradient(135deg,#0e7c7b,#0a5c5b);color:#fff;padding:22px 18px;text-align:center}'
		. '.hd .t1{font-size:15px;letter-spacing:.5px;opacity:.9}'
		. '.wrap{flex:1;display:flex;justify-content:center;padding:22px 14px 40px}'
		. '.card{background:#fff;border-radius:14px;box-shadow:0 2px 14px rgba(10,60,60,.10);max-width:460px;width:100%;padding:26px 22px}'
		. 'h1{font-size:21px;line-height:1.3;margin-bottom:6px}'
		. '.sub{color:#4a5c5c;font-size:14px;margin-bottom:18px}'
		. 'label{display:block;font-size:13px;font-weight:600;margin:14px 0 5px}'
		. 'input[type=text],input[type=email]{width:100%;padding:12px;font-size:16px;border:1px solid #c8d4d4;border-radius:8px}'
		. '.hint{font-size:12.5px;color:#6a7c7c;margin-top:5px;line-height:1.45}'
		. '.btn{display:block;width:100%;margin-top:20px;padding:14px;font-size:17px;font-weight:700;color:#fff;background:#0e7c7b;border:0;border-radius:9px;cursor:pointer}'
		. '.btn:active{background:#0a5c5b}'
		. '.err{background:#fbeae8;color:#a03325;border-left:3px solid #a03325;padding:10px 12px;border-radius:6px;font-size:14px;margin-bottom:14px;line-height:1.45}'
		. '.note{background:#e8f4f4;border-left:3px solid #0e7c7b;padding:10px 12px;border-radius:6px;font-size:13.5px;line-height:1.5;margin-bottom:14px}'
		. '.alt{text-align:center;font-size:13.5px;margin-top:16px;color:#4a5c5c}'
		. '.alt a{color:#0e7c7b}'
		. '.ft{text-align:center;font-size:12px;color:#7a8a8a;padding:14px}'
		. '.hp{position:absolute;left:-9999px;opacity:0;height:0;overflow:hidden}'
		. '</style></head><body>'
		. '<div class="hd"><div class="t1">' . esc_html( $site ) . '</div></div>'
		. '<div class="wrap"><div class="card">';

	if ( 'invalid' === $state ) {
		echo '<h1>This link is not active</h1><p class="sub">This enrollment link is no longer valid. Please check with the person who gave you the flyer, or contact us at hello@hiscornerstone.com and we will get you into your course.</p>';
	} elseif ( 'expired' === $state ) {
		echo '<h1>This enrollment period has ended</h1><p class="sub">The sign-up window for this group has closed. Please contact your administrator, or reach us at hello@hiscornerstone.com.</p>';
	} elseif ( 'full' === $state ) {
		echo '<h1>This group is full</h1><p class="sub">All seats for this group have been used. Please contact your administrator so more seats can be added - or reach us at hello@hiscornerstone.com.</p>';
	} elseif ( 'check_email' === $state ) {
		echo '<h1>Check your email</h1>'
			. '<p class="sub">You already have an account with us, so we kept it - your history and certificates stay together. We just sent a sign-in link to <strong>' . esc_html( $email ) . '</strong>. Tap it to go straight into your course. It works once and expires in 15 minutes.</p>'
			. '<form method="post" action="' . $action . '">'
			. wp_nonce_field( 'hisc_qj_' . $group_id, 'hisc_qj_nonce', true, false )
			. '<input type="hidden" name="hisc_qj_resend" value="1">'
			. '<input type="hidden" name="hisc_qj_email" value="' . esc_attr( $email ) . '">'
			. '<button class="btn" type="submit">Resend the email</button></form>'
			. '<p class="alt">Know your password? <a href="' . esc_url( hisc_qj_login_page_url( hisc_qj_redirect_target( $group_id ) ) ) . '">Log in here instead</a><br>'
			. 'Wrong email? <a href="' . $action . '">Go back</a></p>';
	} else { /* form */
		echo '<h1>' . esc_html( $course_title ) . '</h1>';
		echo '<p class="sub">You are joining this course' . ( $group_title !== '' ? ' - <strong>' . esc_html( $group_title ) . '</strong>' : '' ) . '. One quick step and you will be inside the course. No password needed.</p>';
		if ( '' !== $error ) echo '<div class="err">' . esc_html( $error ) . '</div>';

		if ( is_user_logged_in() ) {
			$me = wp_get_current_user();
			echo '<div class="note">You are signed in as <strong>' . esc_html( $me->display_name ) . '</strong> (' . esc_html( $me->user_email ) . ').</div>'
				. '<form method="post" action="' . $action . '">'
				. wp_nonce_field( 'hisc_qj_' . $group_id, 'hisc_qj_nonce', true, false )
				. '<input type="hidden" name="hisc_qj_continue" value="1">'
				. '<button class="btn" type="submit">Continue as ' . esc_html( $me->first_name !== '' ? $me->first_name : $me->display_name ) . '</button></form>'
				. '<p class="alt">Not you? <a href="' . esc_url( wp_logout_url( $action ) ) . '">Sign out and join as someone else</a></p>';
		} else {
			echo '<form method="post" action="' . $action . '">'
				. wp_nonce_field( 'hisc_qj_' . $group_id, 'hisc_qj_nonce', true, false )
				. '<p class="hp"><label>Website<input type="text" name="hisc_qj_website" tabindex="-1" autocomplete="off"></label></p>'
				. '<label for="qj_first">First name</label><input type="text" id="qj_first" name="hisc_qj_first" required autocomplete="given-name">'
				. '<label for="qj_last">Last name</label><input type="text" id="qj_last" name="hisc_qj_last" required autocomplete="family-name">'
				. '<p class="hint">Use the name on your professional license - it prints on your CE certificate.</p>'
				. '<label for="qj_email">Email</label><input type="email" id="qj_email" name="hisc_qj_email" required autocomplete="email">'
				. '<label for="qj_email2">Confirm email</label><input type="email" id="qj_email2" name="hisc_qj_email2" required autocomplete="email">'
				. '<p class="hint">Your certificate and course access are tied to this email, so please double-check it.</p>'
				. '<button class="btn" type="submit">Start the course</button>'
				. '</form>'
				. '<p class="alt">Already took a course with us? Use the same email and we will send you a one-tap sign-in link.</p>';
		}
	}

	echo '</div></div><div class="ft">Quality Education is the Cornerstone for Quality Care</div></body></html>';
	exit;
}

/* ===================== one-time "set a password" notice ===================== */
/* Shown on course pages to QuickJoin-created accounts until dismissed. Points
   at WP's standard reset flow - the account is a normal account. */

add_filter( 'the_content', function ( $content ) {
	if ( ! is_singular( 'sfwd-courses' ) || ! is_user_logged_in() || ! in_the_loop() || ! is_main_query() ) return $content;
	if ( ! get_user_meta( get_current_user_id(), 'hisc_qj_pw_notice', true ) ) return $content;
	$dismiss = esc_url( add_query_arg( 'hisc_qj_dismiss', wp_create_nonce( 'hisc_qj_dismiss' ) ) );
	$reset   = esc_url( wp_lostpassword_url( get_permalink() ) );
	$box = '<div style="background:#e8f4f4;border-left:3px solid #0e7c7b;padding:12px 14px;border-radius:6px;font-size:14px;line-height:1.55;margin:0 0 18px;">'
		. 'You are signed in - no password needed on this device. Want to log in from another device later? '
		. '<a href="' . $reset . '">Set a password</a> &nbsp;&middot;&nbsp; <a href="' . $dismiss . '">Dismiss</a></div>';
	return $box . $content;
}, 8 );

/* ===================== admin metabox on the group edit screen ===================== */

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'hisc_quickjoin', 'Group QuickJoin (QR enrollment)', 'hisc_qj_metabox', 'groups', 'side', 'high' );
} );

function hisc_qj_metabox( $post ) {
	wp_nonce_field( 'hisc_qj_meta', 'hisc_qj_meta_nonce' );
	$code    = get_post_meta( $post->ID, 'hisc_join_code', true );
	$cap     = hisc_qj_cap( $post->ID );
	$exp     = (int) get_post_meta( $post->ID, 'hisc_join_expires', true );
	$members = hisc_qj_member_count( $post->ID );
	if ( $code ) {
		echo '<p><strong>Join URL (QR target)</strong><br><input type="text" readonly value="' . esc_attr( hisc_qj_join_url( $post->ID ) ) . '" style="width:100%" onclick="this.select()"></p>';
		echo '<p><strong>Enrolled (all paths):</strong> ' . intval( $members ) . ' of ' . intval( $cap ) . '</p>';
	} else {
		echo '<p>No join code yet - one is generated when the group is published.</p>';
	}
	echo '<p><label><strong>Max enrollees</strong><br><input type="number" name="hisc_qj_cap" value="' . esc_attr( $cap ) . '" min="1" style="width:110px"></label><br><span class="description">Default ' . intval( HISC_QJ_DEFAULT_CAP ) . '. Abuse insurance only; existing members can always re-enter.</span></p>';
	$exp_val = $exp ? gmdate( 'Y-m-d', $exp ) : '';
	echo '<input type="hidden" name="hisc_qj_expires_prev" value="' . esc_attr( $exp_val ) . '">';
	echo '<p><label><strong>Code expires</strong><br><input type="date" name="hisc_qj_expires" value="' . esc_attr( $exp_val ) . '"></label><br><span class="description">Blank = never. Default: one year from creation.</span></p>';
	echo '<p><label><input type="checkbox" name="hisc_qj_regen" value="1"> <strong>Regenerate code on save</strong></label><br><span class="description">Instantly disables every QR printed with the current code. The Uncanny group code is not affected.</span></p>';
}

add_action( 'save_post_groups', function ( $post_id ) {
	if ( ! isset( $_POST['hisc_qj_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hisc_qj_meta_nonce'] ) ), 'hisc_qj_meta' ) ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;
	if ( isset( $_POST['hisc_qj_cap'] ) ) {
		update_post_meta( $post_id, 'hisc_join_cap', max( 1, absint( $_POST['hisc_qj_cap'] ) ) );
	}
	if ( isset( $_POST['hisc_qj_expires'] ) ) {
		$d    = sanitize_text_field( wp_unslash( $_POST['hisc_qj_expires'] ) );
		$prev = sanitize_text_field( wp_unslash( $_POST['hisc_qj_expires_prev'] ?? '' ) );
		if ( '' === $d ) {
			/* Only clear when the admin actually blanked a previously-set date.
			   On the very first save the field renders empty (no code existed
			   when the screen loaded) - deleting then would silently wipe the
			   1-year default the priority-10 hook just created. */
			if ( '' !== $prev ) delete_post_meta( $post_id, 'hisc_join_expires' );
		} else {
			$ts = strtotime( $d . ' 23:59:59' );
			if ( $ts ) update_post_meta( $post_id, 'hisc_join_expires', $ts );
		}
	}
	if ( ! empty( $_POST['hisc_qj_regen'] ) ) hisc_qj_generate_code( $post_id );
}, 20 );
